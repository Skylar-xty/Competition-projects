#ifndef CONFIG_H
#define CONFIG_H

#define WINDOW_HEIGHT 750//500

#define WINDOW_WIDTH 1178//785

#define WINDOWS_ICO_PATH ":/res/tb.ico"  //图标路径

#define BACK_PATH ":/res/background.jpg"   //背景图片路径

#endif // CONFIG_H
